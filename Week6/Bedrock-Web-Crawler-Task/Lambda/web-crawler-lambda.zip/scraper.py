"""
Web scraping module with robust error handling
"""

import requests
from urllib.parse import urlparse
import gzip


class WebScraper:
    """
    Fetches web pages with proper handling of gzip, redirects, and size limits
    """
    
    def __init__(self, max_size_mb=10, timeout_seconds=60, max_redirects=5):
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self.timeout = timeout_seconds
        self.max_redirects = max_redirects
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (compatible; AWSBedrockCrawler/1.0)',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
        }
    
    def fetch(self, url):
        """
        Fetch and return HTML content from URL
        
        Returns:
            tuple: (html_content, final_url, content_type)
        """
        # Validate URL
        if not self._is_valid_url(url):
            raise ValueError(f"Invalid URL: {url}")
        
        try:
            # Make request with streaming to check size
            response = requests.get(
                url,
                headers=self.headers,
                timeout=self.timeout,
                allow_redirects=True,
                stream=True
            )
            
            response.raise_for_status()
            
            # Check final URL after redirects
            final_url = response.url
            content_type = response.headers.get('Content-Type', '')
            
            # Validate it's HTML content
            if 'text/html' not in content_type.lower():
                raise ValueError(f"URL does not return HTML content. Content-Type: {content_type}")
            
            # Check content length
            content_length = response.headers.get('Content-Length')
            if content_length and int(content_length) > self.max_size_bytes:
                raise ValueError(f"Content too large: {content_length} bytes (max: {self.max_size_bytes})")
            
            # Read content in chunks to enforce size limit
            content = b''
            for chunk in response.iter_content(chunk_size=8192):
                content += chunk
                if len(content) > self.max_size_bytes:
                    raise ValueError(f"Content exceeded size limit of {self.max_size_bytes} bytes")
            
            # Decode content (handles gzip automatically via requests)
            html_content = content.decode('utf-8', errors='ignore')
            
            return html_content, final_url, content_type
            
        except requests.exceptions.Timeout:
            raise TimeoutError(f"Request timed out after {self.timeout} seconds")
        
        except requests.exceptions.TooManyRedirects:
            raise ValueError(f"Too many redirects (max: {self.max_redirects})")
        
        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"Failed to fetch URL: {str(e)}")
    
    def _is_valid_url(self, url):
        """
        Validate URL format
        """
        try:
            result = urlparse(url)
            return all([result.scheme in ['http', 'https'], result.netloc])
        except Exception:
            return False